# Personal Portfolio Website

A responsive personal portfolio website built with only HTML5 and CSS3 for the EWB Courses HTML & CSS Internship.

## Description
This is a responsive personal portfolio website built with only HTML5 and CSS3. It has a navigation bar, a hero section, About, Skills, Projects, Contact and Footer sections, all linked by section IDs. I used CSS variables for the colour palette, Flexbox and Grid for the layout, and hover and focus states on the buttons and cards. Media queries keep the site readable on tablet and mobile screens with no horizontal scrolling.

## Files
- `index.html` - page structure
- `style.css` - all styling
- `screenshots/` - desktop and mobile views

## Author
Nitharshanaa S, B.E. CSE (2nd year), Dr. N.G.P. Institute of Technology
